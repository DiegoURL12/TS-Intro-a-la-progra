﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L13_DL_1069322

{
    internal class Program
    {
        static void Main(string[] args)
        {
            string menu = "";
            int suma = 0;
            int[,] matriz = new int[4, 5];
            int[,] matriz1 = new int[10, 10];

            while (menu != "D")
            {



                Console.WriteLine("Menú");
                Console.WriteLine("Opcion A Llenar matriz");
                Console.WriteLine("Opcion B Sumatoria de la matriz");
                Console.WriteLine("Opcion C Tabla de miltiplicar");
                Console.WriteLine("Opcion D Sair");
                Console.WriteLine(" ");
                Console.WriteLine("Escoga la opcion:");
                menu = Console.ReadLine();

                switch (menu)
                {
                    case "A":
                        Random num = new Random();
                        for (int f = 0; f < 4; f++)
                        {
                            for (int c = 0; c < 5; c++)
                            {
                                matriz[f, c] = num.Next(150);
                                Console.Write(matriz[f, c] + " ");

                            }
                            Console.WriteLine();
                        }
                        break;

                    case "B":
                        for (int f = 0; f < 4; f++)
                        {
                            for (int c = 0; c < 5; c++)
                            {
                                suma = suma + matriz[f, c];
                            }

                        }
                        Console.WriteLine("La suma es " + suma);
                        break;

                    case "C":
                        for (int f = 0; f < 10; f++)
                        {
                            for (int c = 0; c < 10; c++)
                            {
                                matriz1[f, c] = (f + 1) * (c + 1);
                                Console.Write(matriz1[f, c] + " ");
                            }
                            Console.WriteLine("");
                        }
                        break;
                }
            }
        }
    }
}
