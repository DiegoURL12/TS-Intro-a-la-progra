﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_DL_1069322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int largo = 0;
            int[] vector;
            int suma = 0;
            int sumaa = 0;
            int sumab = 0;

            Console.WriteLine("Ingrese la cantidad de numeros");
            largo = int.Parse(Console.ReadLine());

            vector = new int[largo];

            for (int i = 0; i < vector.Length; i++)
            {
                Console.WriteLine("Ingrese el número:");
                vector[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < vector.Length; i++)
            {
                Console.WriteLine("La posicion " + i + " es: " + vector[i]);
            }
            for (int i = 0; i < vector.Length; i++)
            {
                suma += vector[i];
            }
            for (int i = 0; i < vector.Length; i = i + 2)
            {
                sumab = vector[i];
            }
            for (int i = 0; i < vector.Length; i += 2)
            {
                sumaa += vector[i];
            }


            Console.WriteLine("La suma es: " + suma);

            Console.WriteLine("Longitud del arreglo es: " + vector.Length);

            Console.WriteLine("Suma de posiciónes impares es: " + sumab);

            Console.WriteLine("Suma de posiciones pares es: " + sumaa);

            Console.ReadKey();
        }
    }
}