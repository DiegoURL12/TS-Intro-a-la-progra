﻿// See https://aka.ms/new-console-template for more information
string meses = "Mes: ";
Console.WriteLine("Ejercicio 1");

Console.WriteLine("Ingresar el numero del mes");

int mes = Int32.Parse(Console.ReadLine());

if (mes < 1 | mes > 12)
{
    Console.WriteLine("Eror: el numero a ingresar debe se menor a 12 y mayor a 1");
}
else
{
    switch (mes)
    {
        case 1:
            Console.WriteLine(meses + "Enero");
            break;
        case 2:
            Console.WriteLine(meses + "Febrero");
            break;
        case 3:
            Console.WriteLine(meses + "Marzo");
            break;
        case 4:
            Console.WriteLine(meses + "Abril");
            break;
        case 5:
            Console.WriteLine(meses + "Mayo");
            break;
        case 6:
            Console.WriteLine(meses + "Junio");
            break;
        case 7:
            Console.WriteLine(meses + "Julio");
            break;
        case 8:
            Console.WriteLine(meses + "Agosto");
            break;
        case 9:
            Console.WriteLine(meses + "Septiembre");
            break;
        case 10:
            Console.WriteLine(meses + "Octubre");
            break;
        case 11:
            Console.WriteLine(meses + "Noviembre");
            break;
        case 12:
            Console.WriteLine(meses + "Diciembre");
            break;

    }      
}
try
{

Console.WriteLine("Ejercicio 2");

Console.WriteLine("ingrese el numero 1");
int A = Int32.Parse(Console.ReadLine());

Console.WriteLine("ingrese el numero 2");
int B = Int32.Parse(Console.ReadLine());

Console.WriteLine("ingrese el numero 3");
int C = Int32.Parse(Console.ReadLine());

if (A < 1)
{
    Console.WriteLine("Debe ingresar un número mayor a 0");
}
else if (B < 1)
{
    Console.WriteLine("Debe ingresar un número mayor a 0");
}
else if (C < 1)
{
    Console.WriteLine("Debe ingresar un número mayor a 0");
}
else
{
    if (A > B)
    {
        if (A > C)
        {
            Console.WriteLine("El número mayor es: " + A);
        }
        else if (A == C)
        {
            Console.WriteLine("El número mayor es: " + A);
        }
    }
    else if (A == B)
    {
        if (A > C)
        {
            Console.WriteLine("El número mayor es: " + A);
        }
        else if (A == C)
        {
            Console.WriteLine("El número mayor es: " + A);
        }
    }
    else if (B > C)
    {
        Console.WriteLine("El número mayor es: " + B);
    }
    else if (B == C)
    {
        Console.WriteLine("El número mayor es: " + B);
    }
    else
    {
        Console.WriteLine("El número mayor es: " + C);
    }
}
                           

}
                        catch
{
    Console.WriteLine("Debe ingresar un número");
}
Console.ReadKey();
